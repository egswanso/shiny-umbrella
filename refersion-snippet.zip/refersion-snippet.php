<?php
if(!empty($referralID)) {
		// Create Data Array
		$order_data = array(
			'cart_id' => ''.$accountID.'',
			'order_id'=> ''.$accountID.'',
			'currency_code'=> 'USD',
			'auto_credit_affiliate_id'=>''.$referralID.'',
			'customer'=> array(
				'first_name'=>''.$first_name.'',
				'last_name'=>''.$last_name.'',
				'email'=>''.$email.''
			),
			'items' => array(
				0 => array(
					'price'=> 249.99,
					'quantity'=> 1
				),
			),
		);
		
		// Convert Array to JSON
		$json_data = json_encode($order_data);
		
		// The URL that you are posting to
		$url = 'https://inbound-webhooks.refersion.com/tracker/orders/paid';
		
		// Start cURL
		$curl = curl_init($url);
		curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, TRUE);
		curl_setopt($curl, CURLOPT_CUSTOMREQUEST, 'POST');
		curl_setopt($curl, CURLOPT_POSTFIELDS, $json_data);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, TRUE);
		curl_setopt($curl, CURLOPT_HTTPHEADER, array(
			'Content-Type: application/json',
			'Content-Length: ' . strlen($json_data),
			'Refersion-Public-Key: pub_4b6034882de1d13a4459',
			'Refersion-Secret-Key: sec_714224773bb392fa57ae')
		);
		curl_setopt($curl, CURLOPT_TIMEOUT, 30);
		curl_setopt($curl, CURLOPT_CONNECTTIMEOUT, 30);
		$result = curl_exec($curl);
		$status = curl_getinfo($curl, CURLINFO_HTTP_CODE);
		curl_close($curl);
	}